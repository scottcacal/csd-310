Everything in this Folder is used in creation of the willsonFinancial DB

1. create and populate db by running the script found in [(FINALCreatePopulateDB.py)].
3. to view database information or record use you may use the following scripts in the Final Reports folder [(ViewDATA.py), (ViewTables.py)]
2. run all three reports in whatever order you would like in the Final Reports folder[(FINALAvgClientAssetsReport.py), (FINALHighestTotalAssetsReports.py), (FINALNewClientsAddedPerMonthReport.py)]. 

*Reminder*
For standard user and password within each script. Please remember to update these values locally before running them on your machine.